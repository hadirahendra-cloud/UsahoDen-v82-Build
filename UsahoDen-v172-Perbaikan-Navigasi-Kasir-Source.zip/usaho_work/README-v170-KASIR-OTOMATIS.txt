UsahoDen v170 - Kasir Otomatis Firebase
Basis sumber: v169 Firebase Realtime Backup.
Package: com.tokoku.app
versionCode: 170
versionName: 3.22.30-v170-kasir-otomatis

PERUBAHAN v170
- Setiap transaksi yang dibuat pada sesi login lokal Kasir diberi transactionId unik.
- Transaksi kasir disimpan ke antrean localStorage dan dicoba kirim otomatis ketika perangkat online.
- Firebase menerima transaksi pada shops/{UID_ADMIN}/incoming/{UID_KASIR}/{transactionId}.
- HP Admin mendengarkan transaksi masuk, mencegah impor ganda berdasarkan transactionId, menyesuaikan stok dan piutang, lalu menghapus item antrean cloud setelah diproses.
- Admin dapat memberi izin UID Firebase Kasir dan menerbitkan snapshot produk/pelanggan/pengaturan untuk diunduh Kasir.
- Stok tetap boleh minus; tidak ada validasi stok yang menolak transaksi.
- Backup Firebase v169 tetap berada pada node backups/{uid}.

PENTING - SETUP FIREBASE
1. Firebase Console > Authentication > Sign-in method: aktifkan Email/Password.
2. Firebase Console > Realtime Database > Rules: terapkan isi database.rules dari ZIP ini.
3. HP Admin: login akun Firebase Admin. Pada Pengaturan > Sinkronisasi Kasir, tekan Ambil UID akun Firebase ini. UID tersebut menjadi UID Toko Admin.
4. HP Kasir 2 dan 3: buat/login akun Firebase masing-masing. Ambil UID masing-masing dari tombol yang sama dan salin ke Admin.
5. HP Admin: masukkan UID Kasir, nama perangkat, lalu tekan Izinkan HP Kasir. Ulangi untuk setiap HP Kasir.
6. HP Admin: tekan Kirim Data Produk & Pelanggan ke Kasir.
7. Setiap HP Kasir: login lokal sebagai Kasir, login Firebase dengan akun kasir masing-masing, masukkan UID Admin pada kolom UID Toko Admin, tekan Ambil Data Produk & Pelanggan dari Admin, lalu Aktifkan Sinkronisasi.
8. HP Admin: masukkan UID Admin sendiri dan tekan Aktifkan Sinkronisasi. Biarkan aplikasi Admin terhubung untuk menerima transaksi langsung.

CATATAN OPERASIONAL
- Pengiriman otomatis memerlukan koneksi internet. Saat offline, transaksi disimpan di antrean lokal dan dicoba lagi ketika online / berkala selama aplikasi terbuka.
- Jangan hapus data aplikasi Kasir sebelum antrean transaksi tertunda berhasil terkirim.
- Data master yang dipublikasikan berisi produk, pelanggan, dan pengaturan toko. Jika Admin mengubah produk/pelanggan/harga, terbitkan ulang snapshot agar Kasir mengambil data terbaru.
- Untuk penerimaan transaksi langsung, aplikasi Admin harus terbuka dan terhubung. Jika Admin sedang tidak aktif, data tetap berada di Firebase dan akan dibaca saat listener Admin aktif kembali.
- Local login Kasir hanya membatasi tampilan perangkat. Pengamanan akses cloud sebenarnya diterapkan melalui Firebase Authentication dan database.rules.
- v169 tetap merupakan baseline aman. Jangan menghapus APK/data v169 sebelum v170 selesai diuji pada HP Admin dan kedua HP Kasir.

BUILD
Gunakan Build-UsahoDen-v170-Kasir-Otomatis.yml. Workflow mempertahankan Java Temurin 17, Gradle 8.7, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0, package, serta keystore lama dari GitHub Secrets.
Secrets wajib: TOKOKU_KEYSTORE_BASE64, TOKOKU_KEYSTORE_PASSWORD, TOKOKU_KEY_ALIAS; TOKOKU_KEY_PASSWORD opsional.
