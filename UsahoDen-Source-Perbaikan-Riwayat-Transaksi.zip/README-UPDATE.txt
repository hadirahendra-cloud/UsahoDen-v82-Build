UsahoDen v98 - Tema Header Gonjong Royal Minang

Perubahan terbatas pada dekorasi background header: gradasi biru kerajaan, gonjong Rumah Gadang bergaya ilustrasi digital, dan aksen emas. Logo, nama UsahoDen, nama toko RangMudo Jr., deskripsi, navigasi, data, dan fitur lain tidak sengaja diubah.

Paket aplikasi: com.tokoku.app
Version code: 98
Version name: 3.22.15-header-gonjong-v98

Build melalui GitHub Actions menggunakan keystore lama yang sama agar pembaruan dapat dipasang di atas aplikasi sebelumnya.

Versi v104: hanya tinggi header dipendekkan sedikit melalui padding vertikal. Fitur dan bagian lain tidak sengaja diubah. Gunakan keystore lama untuk update.


v107: hanya memperkecil tombol Keluar. Layout header dan fitur lainnya dipertahankan. versionCode 107.


UsahoDen v108: Tombol Kembali tidak dibuat hanya untuk halaman awal Beranda (home). Tombol Kembali tetap tersedia pada halaman lain. Tidak ada fitur lain yang sengaja diubah. versionCode 108.
