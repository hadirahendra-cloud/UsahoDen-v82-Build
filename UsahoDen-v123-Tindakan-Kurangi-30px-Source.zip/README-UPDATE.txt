UsahoDen v98 - Tema Header Gonjong Royal Minang

Perubahan terbatas pada dekorasi background header: gradasi biru kerajaan, gonjong Rumah Gadang bergaya ilustrasi digital, dan aksen emas. Logo, nama UsahoDen, nama toko RangMudo Jr., deskripsi, navigasi, data, dan fitur lain tidak sengaja diubah.

Paket aplikasi: com.tokoku.app
Version code: 98
Version name: 3.22.15-header-gonjong-v98

Build melalui GitHub Actions menggunakan keystore lama yang sama agar pembaruan dapat dipasang di atas aplikasi sebelumnya.

Versi v104: hanya tinggi header dipendekkan sedikit melalui padding vertikal. Fitur dan bagian lain tidak sengaja diubah. Gunakan keystore lama untuk update.


v107: hanya memperkecil tombol Keluar. Layout header dan fitur lainnya dipertahankan. versionCode 107.


UsahoDen v108: Tombol Kembali tidak dibuat hanya untuk halaman awal Beranda (home). Tombol Kembali tetap tersedia pada halaman lain. Tidak ada fitur lain yang sengaja diubah. versionCode 108.


UsahoDen v110: ikon menu garis tiga dipindahkan dari header ke navigasi bawah menggantikan Pengaturan; Pengaturan dipindahkan ke menu samping. Fitur lain dipertahankan. versionCode 109.

Perubahan v110: tombol Kembali otomatis di bawah header tidak ditampilkan pada halaman Riwayat Transaksi. Tombol Kembali di panel pelanggan tetap dipertahankan.

UsahoDen v114: memakai source dasar v113. Tombol Kembali otomatis tidak ditampilkan hanya pada halaman awal Kasir, dan judul Kasir dirapatkan ke bawah header. Halaman lain dan alur navigasinya dipertahankan. versionCode 114.


UsahoDen v115 change: on the product picker screen, remove only the automatic standalone 'Kembali' bar; keep 'Kembali ke Kasir' and align it horizontally with 'Pilih Produk'. Other product and transaction behavior is unchanged. Stable SDK workflow settings preserved.


UsahoDen v123: halaman Tindakan diturunkan tambahan 10px dari v121 dengan mengubah padding atas sheet dari 40px menjadi 50px. Perubahan hanya pada jarak atas halaman Tindakan; versionCode 122. Pertahankan SDK, Gradle, identitas aplikasi, dan keystore lama.
