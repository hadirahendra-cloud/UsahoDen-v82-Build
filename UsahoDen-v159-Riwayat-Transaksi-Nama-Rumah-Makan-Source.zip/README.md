UsahoDen v159 - Riwayat Transaksi Nama Rumah Makan

Basis source: UsahoDen v158 - Nota Digital Pembayaran Cicilan.

Perubahan: pada halaman Riwayat Transaksi, setiap kartu pelanggan menampilkan nama rumah makan jika data tersebut sudah tersimpan. Pencarian pelanggan juga mencocokkan nama rumah makan. Nama rumah makan kosong tidak menampilkan baris tambahan. Perubahan dibatasi pada daftar pelanggan di Riwayat Transaksi.

Identitas package com.tokoku.app dipertahankan. Pertahankan keystore lama untuk kompatibilitas pembaruan. Build memakai Java Temurin 17, Gradle 8.7, Android SDK platform-tools, platforms;android-35, build-tools;35.0.0.
