UsahoDen v169 — Firebase Realtime Database Backup.
Basis: v168. Storage upload/download replaced with Realtime Database. See README.md and database.rules.
