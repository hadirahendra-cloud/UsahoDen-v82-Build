# UsahoDen v169 — Firebase Realtime Database Backup

Basis source: UsahoDen v168 (Firebase Authentication + Cloud Storage backup).

## Perubahan v169
- Mempertahankan Firebase Authentication email/password yang sudah digunakan pada v168.
- Mengganti penyimpanan backup dari Firebase Cloud Storage ke Firebase Realtime Database.
- Backup disimpan sebagai payload JSON pada `backups/{uid}`; setiap akun hanya dapat membaca/menulis node UID miliknya sendiri jika Rules diterapkan.
- Upload dan unduh memakai Firebase Realtime Database Android SDK.
- Data lokal tetap menjadi data kerja utama; upload hanya menyalin data lokal ke cloud. Pemulihan mengganti data lokal setelah konfirmasi di aplikasi.
- Batas ukuran payload di aplikasi: 8 MiB (di bawah batas maksimum satu write Realtime Database).
- Mempertahankan package `com.tokoku.app`, menaikkan versionCode ke 169, dan tidak mengubah fitur lain.

## Pengaturan Firebase Console
1. Pastikan project `usahoden-rangmudojr` memakai Firebase Authentication → Email/Password (sudah diaktifkan).
2. Pastikan Realtime Database dibuat di region Singapore / `asia-southeast1`. URL yang digunakan aplikasi: `https://usahoden-rangmudojr-default-rtdb.asia-southeast1.firebasedatabase.app/`.
3. Buka Realtime Database → Rules, ganti Rules dengan isi file `database.rules`, lalu tekan Publish. Rules mengharuskan pengguna login dan membatasi setiap akun ke UID miliknya.
4. Tidak perlu mengaktifkan Cloud Storage atau upgrade ke paket Blaze untuk fitur backup v169 ini.

## Cara menggunakan
1. Instal APK v169 sebagai update di atas aplikasi lama; jangan uninstall.
2. Buka Pengaturan → Backup Cloud Firebase. Login memakai akun Firebase yang sama dengan v168.
3. Buat backup lokal terlebih dahulu melalui tombol Backup Data.
4. Tekan Upload Backup ke Cloud. Tunggu pesan berhasil.
5. Untuk pemulihan, login dengan akun yang sama lalu tekan Pulihkan dari Cloud. Aplikasi meminta konfirmasi dan memvalidasi struktur backup sebelum mengganti data lokal.

## Build
Workflow GitHub Actions: `.github/workflows/build.yml`. Gunakan Java Temurin 17, Gradle 8.7, Android SDK platform-tools, platforms;android-35, build-tools;35.0.0, dan keystore lama melalui GitHub Secrets: `TOKOKU_KEYSTORE_BASE64`, `TOKOKU_KEYSTORE_PASSWORD`, `TOKOKU_KEY_ALIAS`, serta opsional `TOKOKU_KEY_PASSWORD`.
