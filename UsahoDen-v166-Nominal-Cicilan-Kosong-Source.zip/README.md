UsahoDen v164 - Fix Pilihan Pelanggan Kasir

Basis source: UsahoDen v163 - Notifikasi Global Fix.

Perubahan: memperbaiki dialog pemilihan pelanggan pada halaman Kasir yang tampil tetapi tidak merespons sentuhan. Modal pemilih pelanggan dinaikkan di atas header tetap (z-index 95), area daftar dan tombol pilihan dibuat menerima sentuhan, dan pemilihan memakai event delegation berbasis data-customer-id. Fungsi pilih pelanggan tetap memanggil chooseCashierCustomer, memperbarui label, menutup dialog, lalu menjalankan customerChanged agar harga khusus dan keranjang dihitung ulang.

Nama rumah makan dan ukuran font 16px/13px tetap dipertahankan. Perbaikan notifikasi global v163 tetap dipertahankan.

Versi: versionCode 164, versionName 3.22.24-v164-kasir-pilihan-pelanggan-fix. Package com.tokoku.app dipertahankan. Pertahankan keystore lama untuk kompatibilitas update. Build: Java Temurin 17, Gradle 8.7, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0.


UsahoDen v166: kolom 'Nominal cicilan berikutnya' tidak lagi memiliki nilai bawaan 100000; kolom tampil kosong dan pengguna mengisi sendiri.
