package com.tokoku.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.ClipData;
import android.content.Context;
import android.net.Uri;
import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import android.util.Base64;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.view.Window;
import android.view.View;
import android.widget.LinearLayout;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import java.util.Set;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;
import android.os.Handler;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.ChildEventListener;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout splash;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int BACKUP_CREATE_REQUEST = 1002;
    private static final int BLUETOOTH_PERMISSION_REQUEST = 1003;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private String pendingBackupJson;
    private static final long SPLASH_DURATION_MS = 3000L;
    private final Handler splashHandler = new Handler();
    private long splashStartTime;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_main);
        splashStartTime = System.currentTimeMillis();
        webView = (WebView) findViewById(R.id.webview);
        splash = (LinearLayout) findViewById(R.id.splash);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                try {
                    String installedVersion = getPackageManager()
                        .getPackageInfo(getPackageName(), 0).versionName;
                    String displayVersion = installedVersion == null ? "Tidak diketahui" : installedVersion;
                    java.util.regex.Matcher versionMatcher =
                        java.util.regex.Pattern.compile("v[0-9]+", java.util.regex.Pattern.CASE_INSENSITIVE)
                            .matcher(displayVersion);
                    if (versionMatcher.find()) displayVersion = versionMatcher.group();
                    String versionJson = JSONObject.quote(displayVersion);
                    view.evaluateJavascript(
                        "(function(){var e=document.getElementById('appVersionValue');" +
                        "if(e)e.textContent=" + versionJson + ";})();", null);
                } catch (Exception ignored) { }
                long elapsed = System.currentTimeMillis() - splashStartTime;
                long remaining = Math.max(0L, SPLASH_DURATION_MS - elapsed);
                if (splash != null) {
                    splashHandler.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (splash != null) splash.setVisibility(View.GONE);
                        }
                    }, remaining);
                }
                getWindow().setStatusBarColor(android.graphics.Color.WHITE);
                getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try {
                    intent = params.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.setType("image/*");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        webView.addJavascriptInterface(new FirebaseBridge(), "AndroidFirebase");
        try { FirebaseApp.initializeApp(getApplicationContext()); } catch (Exception ignored) {}
        getWindow().setStatusBarColor(android.graphics.Color.WHITE);
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightNavigationBars(true);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BLUETOOTH_PERMISSION_REQUEST) {
            boolean ok = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ok = checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
            }
            if (webView != null) {
                final boolean result = ok;
                webView.post(new Runnable() {
                    @Override public void run() {
                        webView.evaluateJavascript("if(window.onBluetoothPermissionResult)window.onBluetoothPermissionResult(" +
                                (result ? "true" : "false") + ")", null);
                    }
                });
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_CREATE_REQUEST) {
            try {
                if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                    Uri uri = data.getData();
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("Tidak dapat membuka lokasi penyimpanan");
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                    }
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(true)", null);
                } else {
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            } catch (Exception e) {
                webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
            } finally {
                pendingBackupJson = null;
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class BackupBridge {
        @JavascriptInterface public void saveBackup(final String json, final String filename) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    pendingBackupJson = json == null ? "" : json;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty() ? "tokoku-backup.json" : filename);
                    startActivityForResult(intent, BACKUP_CREATE_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    webView.evaluateJavascript("if(window.onAndroidBackupSaved)window.onAndroidBackupSaved(false)", null);
                }
            }});
        }
    }

    public class ShareBridge {
        @JavascriptInterface public void share(final String text) {
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Bagikan nota"));
            }});
        }
        @JavascriptInterface public void sendWhatsAppImage(final String dataUrl, final String phone, final String caption) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    String base64 = dataUrl;
                    int comma = base64.indexOf(',');
                    if (comma >= 0) base64 = base64.substring(comma + 1);
                    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                    if (bytes == null || bytes.length == 0) throw new IllegalArgumentException("Gambar nota kosong");
                    File dir = new File(getCacheDir(), "shared_images");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Folder gambar tidak dapat dibuat");
                    File image = new File(dir, "nota-usahoden-" + System.currentTimeMillis() + ".jpg");
                    try (FileOutputStream out = new FileOutputStream(image)) {
                        out.write(bytes);
                        out.flush();
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.tokoku.app.fileprovider", image);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("image/jpeg");
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TEXT, caption == null ? "" : caption);
                    i.setClipData(ClipData.newUri(getContentResolver(), "Nota UsahoDen", uri));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    // Use Android's share chooser so WhatsApp and WhatsApp Business can both receive the image.
                    // ClipData plus URI grant is required by modern Android versions for FileProvider images.
                    Intent chooser = Intent.createChooser(i, "Kirim gambar nota melalui");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(chooser);
                } catch (Exception e) {
                    if (webView != null) {
                        final String msg = e.getMessage() == null ? "kesalahan berbagi gambar" : e.getMessage();
                        webView.post(new Runnable() { @Override public void run() {
                            webView.evaluateJavascript("if(window.toast)toast('Gagal membuka berbagi gambar: " +
                                msg.replace("\\", "\\\\").replace("'", "\\'") + "')", null);
                        }});
                    }
                }
            }});
        }

        @JavascriptInterface public void sendWhatsApp(final String text, final String phone) {
            runOnUiThread(new Runnable() { @Override public void run() {
                try {
                    if (phone != null && !phone.isEmpty()) {
                        String url = "https://wa.me/" + phone + "?text=" + URLEncoder.encode(text, "UTF-8");
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    } else {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        i.setPackage("com.whatsapp");
                        startActivity(i);
                    }
                } catch (Exception e) {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Kirim nota ke WhatsApp"));
                }
            }});
        }
    }

    public class PrinterBridge {
        @JavascriptInterface
        public void requestBluetoothPermission() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                            checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.BLUETOOTH_SCAN
                            }, BLUETOOTH_PERMISSION_REQUEST);
                            return;
                        }
                    }
                    notifyBluetoothPermission(true);
                }
            });
        }

        private void notifyBluetoothPermission(boolean ok) {
            webView.evaluateJavascript("if(window.onBluetoothPermissionResult)window.onBluetoothPermissionResult(" + (ok ? "true" : "false") + ")", null);
        }

        @JavascriptInterface
        public void listPairedPrinters() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            webView.evaluateJavascript("if(window.onBluetoothPrinterList)window.onBluetoothPrinterList('PERMISSION_REQUIRED')", null);
                            return;
                        }
                        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                        if (adapter == null) {
                            webView.evaluateJavascript("if(window.onBluetoothPrinterList)window.onBluetoothPrinterList('NO_BLUETOOTH')", null);
                            return;
                        }
                        if (!adapter.isEnabled()) {
                            webView.evaluateJavascript("if(window.onBluetoothPrinterList)window.onBluetoothPrinterList('BLUETOOTH_OFF')", null);
                            return;
                        }
                        JSONArray arr = new JSONArray();
                        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
                        for (BluetoothDevice d : bonded) {
                            JSONObject o = new JSONObject();
                            o.put("name", d.getName() == null ? "Printer Bluetooth" : d.getName());
                            o.put("address", d.getAddress());
                            arr.put(o);
                        }
                        webView.evaluateJavascript("if(window.onBluetoothPrinterList)window.onBluetoothPrinterList(" +
                                JSONObject.quote(arr.toString()) + ")", null);
                    } catch (Exception e) {
                        webView.evaluateJavascript("if(window.onBluetoothPrinterList)window.onBluetoothPrinterList('ERROR')", null);
                    }
                }
            });
        }

        @JavascriptInterface
        public void printBluetooth(final String address, final String text, final String widthText, final String logoModeText, final String logoSizeText, final String logoGapText, final String compactText) {
            new Thread(new Runnable() {
                @Override public void run() {
                    java.io.OutputStream out = null;
                    android.bluetooth.BluetoothSocket socket = null;
                    boolean connectionEstablished = false;
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            notifyPrint(false, "Izin Bluetooth belum diberikan.");
                            return;
                        }

                        if (address == null || address.trim().isEmpty()) {
                            notifyPrint(false, "Printer belum dipilih.");
                            return;
                        }

                        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                        if (adapter == null) {
                            notifyPrint(false, "HP tidak memiliki Bluetooth.");
                            return;
                        }
                        if (!adapter.isEnabled()) {
                            notifyPrint(false, "Bluetooth HP masih mati. Nyalakan Bluetooth lalu coba lagi.");
                            return;
                        }

                        BluetoothDevice device = adapter.getRemoteDevice(address);
                        if (device == null) {
                            notifyPrint(false, "Printer tidak ditemukan. Pair ulang printer di Pengaturan Bluetooth HP.");
                            return;
                        }

                        // Pastikan printer masih tercatat sebagai perangkat yang sudah dipasangkan.
                        Set<BluetoothDevice> pairedDevices = adapter.getBondedDevices();
                        boolean isPaired = false;
                        if (pairedDevices != null) {
                            for (BluetoothDevice paired : pairedDevices) {
                                if (address.equalsIgnoreCase(paired.getAddress())) {
                                    isPaired = true;
                                    break;
                                }
                            }
                        }
                        if (!isPaired || device.getBondState() != BluetoothDevice.BOND_BONDED) {
                            notifyPrint(false, "Printer belum terhubung. Pair printer melalui Pengaturan Bluetooth HP, lalu pilih kembali printer di UsahoDen.");
                            return;
                        }

                        adapter.cancelDiscovery();

                        // Sebagian printer thermal lebih stabil dengan koneksi RFCOMM insecure.
                        try {
                            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                            socket.connect();
                        } catch (Exception secureError) {
                            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                            socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                            socket.connect();
                        }
                        connectionEstablished = true;

                        out = socket.getOutputStream();
                        if (out == null) {
                            notifyPrint(false, "Printer belum siap menerima data. Pastikan printer menyala dan Bluetooth-nya terhubung, lalu coba lagi.");
                            return;
                        }

                        int width = 58;
                        try { width = Integer.parseInt(widthText); } catch (Exception ignored) {}
                        if (width != 80) width = 58;

                        // ESC/POS: pengaturan logo dan jarak bisa diubah langsung dari aplikasi.
                        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                        buffer.write(new byte[]{0x1B, 0x40}); // initialize
                        boolean printLogo = !"off".equalsIgnoreCase(logoModeText);
                        if (printLogo) {
                          buffer.write(new byte[]{0x1B, 0x61, 0x01}); // center logo
                          Bitmap originalLogo = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_rangmudo);
                          if (originalLogo != null) {
                            String size = logoSizeText == null ? "medium" : logoSizeText;
                            int maxWidth;
                            if (width == 80) maxWidth = "small".equals(size) ? 240 : ("large".equals(size) ? 480 : 360);
                            else maxWidth = "small".equals(size) ? 160 : ("large".equals(size) ? 320 : 240);
                            int logoWidth = Math.min(maxWidth, originalLogo.getWidth());
                            int logoHeight = Math.max(1, originalLogo.getHeight() * logoWidth / originalLogo.getWidth());
                            Bitmap logo = Bitmap.createScaledBitmap(originalLogo, logoWidth, logoHeight, true);
                            int bytesPerRow = (logoWidth + 7) / 8;
                            buffer.write(new byte[]{0x1D, 0x76, 0x30, 0x00,
                                (byte)(bytesPerRow & 0xFF), (byte)((bytesPerRow >> 8) & 0xFF),
                                (byte)(logoHeight & 0xFF), (byte)((logoHeight >> 8) & 0xFF)});
                            for (int y = 0; y < logoHeight; y++) {
                                for (int bx = 0; bx < bytesPerRow; bx++) {
                                    int packed = 0;
                                    for (int bit = 0; bit < 8; bit++) {
                                        int x = bx * 8 + bit;
                                        if (x < logoWidth) {
                                            int pixel = logo.getPixel(x, y);
                                            int gray = (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000;
                                            if (Color.alpha(pixel) > 100 && gray < 170) packed |= (0x80 >> bit);
                                        }
                                    }
                                    buffer.write(packed);
                                }
                            }
                            if (logo != originalLogo) logo.recycle();
                            originalLogo.recycle();
                          }
                          int logoGap = 1;
                          try { logoGap = Integer.parseInt(logoGapText); } catch (Exception ignored) {}
                          if (logoGap < 0) logoGap = 0;
                          if (logoGap > 2) logoGap = 2;
                          for (int i = 0; i < logoGap; i++) buffer.write(new byte[]{0x0A});
                        }
                        buffer.write(new byte[]{0x1B, 0x61, 0x00}); // left aligned receipt text

                        String printable = text == null ? "" : text;
                        if ("true".equalsIgnoreCase(compactText)) {
                            printable = printable.replaceAll("[\\t ]+\\n", "\n");
                            printable = printable.replaceAll("\\n{3,}", "\n\n");
                            printable = printable.trim() + "\n";
                        }
                        byte[] body = printable.getBytes(java.nio.charset.Charset.forName("ISO-8859-1"));
                        buffer.write(body);
                        buffer.write(new byte[]{0x0A, 0x0A});

                        out.write(buffer.toByteArray());
                        out.flush();

                        notifyPrint(true, "Nota berhasil dikirim ke " +
                                (device.getName() == null ? "printer" : device.getName()) +
                                " (" + width + " mm).");
                    } catch (SecurityException e) {
                        notifyPrint(false, "Akses Bluetooth ditolak. Izinkan akses Bluetooth untuk TokoKu.");
                    } catch (Exception e) {
                        String msg = e.getMessage();
                        String detail = msg == null ? "" : msg.toLowerCase(java.util.Locale.ROOT);
                        if (!connectionEstablished || detail.contains("file descriptor") ||
                                detail.contains("socket") || detail.contains("connection") ||
                                detail.contains("connect") || detail.contains("read failed")) {
                            notifyPrint(false, "Printer belum dapat dihubungkan. Pastikan printer sudah DINYALAKAN, baterai cukup, dan Bluetooth printer aktif. Jika masih gagal, hubungkan ulang printer dari Pengaturan Bluetooth HP lalu coba cetak kembali.");
                        } else {
                            notifyPrint(false, "Gagal mengirim struk ke printer. Periksa kertas, baterai, dan koneksi printer, lalu coba lagi. Detail: " +
                                    (msg == null || msg.trim().isEmpty() ? "printer tidak merespons." : msg));
                        }
                    } finally {
                        try { if (out != null) out.close(); } catch (Exception ignored) {}
                        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                    }
                }
            }).start();
        }

        private void notifyPrint(boolean ok, String message) {
            final String safe = JSONObject.quote(message == null ? "" : message);
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    webView.evaluateJavascript("if(window.onBluetoothPrintResult)window.onBluetoothPrintResult(" +
                            (ok ? "true" : "false") + "," + safe + ")", null);
                }
            });
        }
    }


    public class FirebaseBridge {
        private static final String DATABASE_URL = "https://usahoden-rangmudojr-default-rtdb.asia-southeast1.firebasedatabase.app/";
        private FirebaseAuth auth() { return FirebaseAuth.getInstance(); }
        private DatabaseReference backupRef(FirebaseUser user) {
            return FirebaseDatabase.getInstance(DATABASE_URL).getReference("backups").child(user.getUid());
        }
        private DatabaseReference shopRef(String ownerUid) {
            return FirebaseDatabase.getInstance(DATABASE_URL).getReference("shops").child(ownerUid);
        }
        private ChildEventListener incomingListener;
        private DatabaseReference incomingRef;
        private void notifySaleSend(boolean ok, String transactionId, String message) {
            final String id = JSONObject.quote(transactionId == null ? "" : transactionId);
            final String msg = JSONObject.quote(message == null ? "" : message);
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onCloudSaleSent)window.onCloudSaleSent("+(ok?"true":"false")+","+id+","+msg+")", null); });
        }
        private void notifyIncoming(String cashierUid, String transactionId, String json) {
            final String c = JSONObject.quote(cashierUid == null ? "" : cashierUid);
            final String id = JSONObject.quote(transactionId == null ? "" : transactionId);
            final String data = JSONObject.quote(json == null ? "{}" : json);
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onCloudSaleReceived)window.onCloudSaleReceived("+c+","+id+","+data+")", null); });
        }
        @JavascriptInterface public void getUid() {
            FirebaseUser u = auth().getCurrentUser();
            String uid = u == null ? "" : u.getUid();
            final String safe = JSONObject.quote(uid);
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onFirebaseUid)window.onFirebaseUid("+safe+")", null); });
        }
        @JavascriptInterface public void grantCashier(String ownerUid, String cashierUid, String label) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null || ownerUid == null || !u.getUid().equals(ownerUid.trim())) { notifyBackup(false, "Hanya akun Admin pemilik toko yang dapat mengizinkan kasir."); return; }
            if (cashierUid == null || cashierUid.trim().isEmpty()) { notifyBackup(false, "UID akun kasir wajib diisi."); return; }
            java.util.Map<String,Object> member = new java.util.HashMap<>(); member.put("active", true); member.put("label", label == null ? "Kasir" : label); member.put("createdAt", System.currentTimeMillis());
            shopRef(ownerUid).child("members").child(cashierUid.trim()).setValue(member).addOnCompleteListener(t -> notifyBackup(t.isSuccessful(), t.isSuccessful() ? "Akun kasir berhasil diizinkan." : "Gagal mengizinkan kasir: "+safeError(t.getException())));
        }
        @JavascriptInterface public void publishState(String ownerUid, String json) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null || ownerUid == null || !u.getUid().equals(ownerUid.trim())) { notifyBackup(false, "Hanya Admin pemilik toko yang dapat mengirim data master."); return; }
            if (json == null || json.length() > 7000000) { notifyBackup(false, "Data master kosong atau melebihi batas aman."); return; }
            shopRef(ownerUid.trim()).child("state").setValue(json).addOnCompleteListener(t -> notifyBackup(t.isSuccessful(), t.isSuccessful() ? "Data produk dan pelanggan berhasil diterbitkan untuk HP Kasir." : "Gagal menerbitkan data master: "+safeError(t.getException())));
        }
        @JavascriptInterface public void downloadState(String ownerUid) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null || ownerUid == null || ownerUid.trim().isEmpty()) { notifyBackup(false, "Login Firebase dan UID Admin diperlukan."); return; }
            shopRef(ownerUid.trim()).child("state").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot snap) {
                    String raw = snap.getValue(String.class);
                    if (raw == null || raw.trim().isEmpty()) { notifyBackup(false, "Data master belum diterbitkan oleh Admin."); return; }
                    final String safe = JSONObject.quote(raw);
                    runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("if(window.onFirebaseMasterData)window.onFirebaseMasterData("+safe+")", null); });
                }
                @Override public void onCancelled(DatabaseError error) { notifyBackup(false, "Unduh data master gagal: "+error.getMessage()); }
            });
        }
        @JavascriptInterface public void sendSale(String ownerUid, String transactionId, String json) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null) { notifySaleSend(false, transactionId, "Login Firebase kasir diperlukan."); return; }
            if (ownerUid == null || ownerUid.trim().isEmpty() || transactionId == null || !transactionId.matches("[A-Za-z0-9_-]{8,100}")) { notifySaleSend(false, transactionId, "Pengaturan toko atau ID transaksi tidak valid."); return; }
            if (json == null || json.length() > 300000) { notifySaleSend(false, transactionId, "Data transaksi kosong atau terlalu besar."); return; }
            String cashierUid = u.getUid();
            DatabaseReference target = shopRef(ownerUid.trim()).child("incoming").child(cashierUid).child(transactionId);
            target.setValue(json).addOnCompleteListener(t -> notifySaleSend(t.isSuccessful(), transactionId, t.isSuccessful() ? "Transaksi terkirim ke Admin." : "Belum terkirim: "+safeError(t.getException())));
        }
        @JavascriptInterface public void listenIncoming(String ownerUid) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null || ownerUid == null || !u.getUid().equals(ownerUid.trim())) { notifyBackup(false, "Penerimaan transaksi hanya aktif pada akun Admin pemilik toko."); return; }
            if (incomingListener != null && incomingRef != null) incomingRef.removeEventListener(incomingListener);
            incomingRef = shopRef(ownerUid.trim()).child("incoming");
            incomingListener = new ChildEventListener() {
                @Override public void onChildAdded(DataSnapshot cashier, String previous) {
                    String cashierUid = cashier.getKey();
                    for (DataSnapshot item : cashier.getChildren()) {
                        String raw = item.getValue(String.class);
                        if (raw != null) notifyIncoming(cashierUid, item.getKey(), raw);
                    }
                }
                @Override public void onChildChanged(DataSnapshot cashier, String previous) { onChildAdded(cashier, previous); }
                @Override public void onChildRemoved(DataSnapshot s) {}
                @Override public void onChildMoved(DataSnapshot s, String p) {}
                @Override public void onCancelled(DatabaseError e) { notifyBackup(false, "Listener transaksi kasir gagal: "+e.getMessage()); }
            };
            incomingRef.addChildEventListener(incomingListener);
        }
        @JavascriptInterface public void acknowledgeSale(String ownerUid, String cashierUid, String transactionId) {
            FirebaseUser u = auth().getCurrentUser();
            if (u == null || ownerUid == null || !u.getUid().equals(ownerUid.trim())) return;
            shopRef(ownerUid.trim()).child("incoming").child(cashierUid).child(transactionId).removeValue();
        }
        private void notifyAuth(boolean ok, String message, String email) {
            final String m = JSONObject.quote(message == null ? "" : message);
            final String e = JSONObject.quote(email == null ? "" : email);
            runOnUiThread(new Runnable() { @Override public void run() {
                if (webView != null) webView.evaluateJavascript("if(window.onFirebaseAuthResult)window.onFirebaseAuthResult(" + (ok ? "true" : "false") + "," + m + "," + e + ")", null);
            }});
        }
        private void notifyBackup(boolean ok, String message) {
            final String m = JSONObject.quote(message == null ? "" : message);
            runOnUiThread(new Runnable() { @Override public void run() {
                if (webView != null) webView.evaluateJavascript("if(window.onFirebaseBackupResult)window.onFirebaseBackupResult(" + (ok ? "true" : "false") + "," + m + ")", null);
            }});
        }
        @JavascriptInterface public void signIn(String email, String password) {
            try { auth().signInWithEmailAndPassword(email == null ? "" : email.trim(), password == null ? "" : password)
                .addOnCompleteListener(task -> { if (task.isSuccessful()) { FirebaseUser u = auth().getCurrentUser(); notifyAuth(true, "Login Firebase berhasil.", u == null ? "" : u.getEmail()); } else notifyAuth(false, "Login Firebase gagal: " + safeError(task.getException()), ""); });
            } catch (Exception e) { notifyAuth(false, "Firebase belum siap: " + safeError(e), ""); }
        }
        @JavascriptInterface public void signUp(String email, String password) {
            try { auth().createUserWithEmailAndPassword(email == null ? "" : email.trim(), password == null ? "" : password)
                .addOnCompleteListener(task -> { if (task.isSuccessful()) { FirebaseUser u = auth().getCurrentUser(); notifyAuth(true, "Akun Firebase berhasil dibuat.", u == null ? "" : u.getEmail()); } else notifyAuth(false, "Pendaftaran gagal: " + safeError(task.getException()), ""); });
            } catch (Exception e) { notifyAuth(false, "Firebase belum siap: " + safeError(e), ""); }
        }
        @JavascriptInterface public void signOut() { try { auth().signOut(); notifyAuth(true, "Keluar dari akun Firebase.", ""); } catch (Exception e) { notifyAuth(false, safeError(e), ""); } }
        @JavascriptInterface public void getStatus() {
            try { FirebaseUser u = auth().getCurrentUser(); notifyAuth(true, u == null ? "Belum login Firebase." : "Terhubung sebagai " + u.getEmail(), u == null ? "" : u.getEmail()); }
            catch (Exception e) { notifyAuth(false, "Firebase belum siap: " + safeError(e), ""); }
        }
        @JavascriptInterface public void uploadBackup(String json) {
            try {
                FirebaseUser user = auth().getCurrentUser();
                if (user == null) { notifyBackup(false, "Login Firebase terlebih dahulu."); return; }
                if (json == null || json.trim().isEmpty()) { notifyBackup(false, "Data backup kosong."); return; }
                byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
                // Realtime Database limits an individual write to 10 MB; keep a safety margin.
                if (bytes.length > 8 * 1024 * 1024) { notifyBackup(false, "Ukuran backup melebihi batas aman 8 MB untuk Realtime Database."); return; }
                backupRef(user).setValue(json).addOnCompleteListener(task -> {
                    if (task.isSuccessful()) notifyBackup(true, "Backup cloud berhasil diunggah ke Realtime Database. Data lokal tetap tersimpan.");
                    else notifyBackup(false, "Backup Realtime Database gagal: " + safeError(task.getException()));
                });
            } catch (Exception e) { notifyBackup(false, "Realtime Database belum siap: " + safeError(e)); }
        }
        @JavascriptInterface public void downloadBackup() {
            try {
                FirebaseUser user = auth().getCurrentUser();
                if (user == null) { notifyBackup(false, "Login Firebase terlebih dahulu."); return; }
                backupRef(user).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        String json = snapshot.getValue(String.class);
                        if (json == null || json.trim().isEmpty()) {
                            notifyBackup(false, "Belum ada backup cloud untuk akun ini. Unggah backup terlebih dahulu.");
                            return;
                        }
                        final String safe = JSONObject.quote(json);
                        runOnUiThread(new Runnable() { @Override public void run() {
                            if (webView != null) webView.evaluateJavascript("if(window.onFirebaseRestoreData)window.onFirebaseRestoreData(" + safe + ")", null);
                        }});
                    }
                    @Override public void onCancelled(DatabaseError error) {
                        notifyBackup(false, "Unduh backup Realtime Database gagal: " + error.getMessage());
                    }
                });
            } catch (Exception e) { notifyBackup(false, "Realtime Database belum siap: " + safeError(e)); }
        }
        private String safeError(Exception e) {
            if (e == null || e.getMessage() == null) return "Periksa koneksi dan pengaturan Firebase.";
            String msg = e.getMessage();
            if (msg.length() > 220) msg = msg.substring(0, 220);
            return msg;
        }
    }

    public class PrintBridge {
        @JavascriptInterface public void printReceipt(final String text, final String widthText) {
            runOnUiThread(new Runnable() { @Override public void run() {
                final int widthMm;
                try { widthMm = Integer.parseInt(widthText); } catch (Exception e) { return; }
                final WebView printWebView = new WebView(MainActivity.this);
                WebSettings ps = printWebView.getSettings();
                ps.setJavaScriptEnabled(true);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String jobName = "TokoKu Struk " + widthMm + "mm";
                        PrintDocumentAdapter adapter = printWebView.createPrintDocumentAdapter(jobName);
                        int widthMils = widthMm == 80 ? 3150 : 2283;
                        PrintAttributes.MediaSize media = new PrintAttributes.MediaSize(
                                widthMm == 80 ? "TOKO_80" : "TOKO_58",
                                widthMm == 80 ? "80mm" : "58mm",
                                widthMils, 11000);
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(media)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(jobName, adapter, attrs);
                    }
                });
                String safe = escapeHtml(text);
                String html = "<!doctype html><html><head><meta charset='utf-8'><style>" +
                        "@page{size:" + widthMm + "mm auto;margin:0}" +
                        "html,body{margin:0;padding:0;background:#fff}" +
                        "pre{font-family:monospace;font-size:11px;line-height:1.25;white-space:pre-wrap;word-break:break-word;width:" +
                        (widthMm - 6) + "mm;margin:3mm auto}" +
                        "</style></head><body><pre>" + safe + "</pre></body></html>";
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }});
        }
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
