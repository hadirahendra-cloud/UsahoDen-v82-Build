UsahoDen v175 - Password Kasir Perangkat

Berasal dari baseline v174.
Perubahan:
- Perangkat kasir menggunakan username tetap kasir.
- Password login kasir disimpan terpisah pada masing-masing perangkat.
- Menu Ubah Password Kasir di HP Ini berada di halaman Akun Firebase.
- Memerlukan password lama, password baru minimal 4 karakter, dan konfirmasi.
- Perubahan password satu perangkat tidak mengubah perangkat kasir lain.
- Password Admin dan sinkronisasi transaksi Firebase v174 tidak diubah.

Password awal lokal perangkat kasir: 1234, apabila belum pernah diubah.
Package: com.tokoku.app
versionCode: 175
