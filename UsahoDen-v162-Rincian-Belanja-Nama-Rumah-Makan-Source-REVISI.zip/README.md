UsahoDen v160 - Nama Rumah Makan pada Pemilihan Pelanggan Kasir

Basis source: UsahoDen v159 - Riwayat Transaksi Nama Rumah Makan.

Perubahan: pada pilihan pelanggan di halaman Kasir, label setiap pelanggan menampilkan nama pelanggan dan, jika tersedia, nama rumah makan dalam format "Nama — Rumah Makan: ...". Jika nama rumah makan kosong, hanya nama pelanggan yang ditampilkan. Pemilihan pelanggan, ID pelanggan, harga khusus, dan alur transaksi tetap menggunakan mekanisme sebelumnya.

Versi: versionCode 160, versionName 3.22.20-v160-kasir-rumah-makan. Package com.tokoku.app dipertahankan. Pertahankan keystore lama untuk kompatibilitas update. Build: Java Temurin 17, Gradle 8.7, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0.
