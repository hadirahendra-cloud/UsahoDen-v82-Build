UsahoDen v152 - Riwayat Transaksi: Nama Pelanggan Kiri, Tombol Kembali Kanan

Dasar: source v151 Nota Rumah Makan yang dikirim pengguna.
Perubahan tunggal: pada baris halaman Riwayat Transaksi untuk pelanggan terpilih, nama pelanggan ditampilkan di kiri dan tombol Kembali di kanan. Nama panjang akan dipotong dengan elipsis agar tombol tetap terlihat.
Tidak mengubah fitur transaksi, nota, data pelanggan, ataupun navigasi lain.

Package/applicationId: com.tokoku.app
versionCode: 152
versionName: 3.22.15-v152-riwayat-tombol-kembali-kanan
Signing: gunakan keystore lama agar tetap kompatibel untuk update.
