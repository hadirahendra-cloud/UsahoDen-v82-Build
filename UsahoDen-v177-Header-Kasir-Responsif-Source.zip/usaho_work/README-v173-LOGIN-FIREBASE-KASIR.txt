UsahoDen v173 - Login Firebase Kasir

Perubahan: menambahkan panel login/logout Firebase khusus di halaman Kasir. HP Kasir dapat masuk dengan akun Firebase miliknya sendiri tanpa membuka menu pengelolaan Admin. Status login Firebase tampil langsung pada halaman Kasir. Callback login Firebase juga memperbarui status di panel Kasir dan tetap menjalankan aktivasi sinkronisasi sesuai UID Toko Admin yang tersimpan.

Perubahan dibatasi pada akses login Firebase kasir. Identitas aplikasi com.tokoku.app, keystore/signing, data lokal, fitur transaksi, sinkronisasi otomatis, antrean offline, dan navigasi kasir v172 dipertahankan.

Build: Java Temurin 17, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0, Gradle 8.7.
