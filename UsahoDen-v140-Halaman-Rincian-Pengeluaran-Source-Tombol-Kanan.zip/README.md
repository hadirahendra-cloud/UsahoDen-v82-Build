# UsahoDen v139 — Pengeluaran Tanggal Vertikal

Baseline: UsahoDen v138 Pengeluaran Date Filter yang telah dikonfirmasi berhasil diinstal pengguna.

## Perubahan v139
- Daftar tanggal pengeluaran ditampilkan vertikal, berurutan dari tanggal paling awal ke terbaru.
- Setiap baris menampilkan tanggal dan jumlah item di kiri serta total pengeluaran di kanan.
- Mengetuk tanggal menampilkan rincian item untuk tanggal tersebut.
- Kalender tanggal pengeluaran memungkinkan pencatatan pengeluaran yang terlewat pada tanggal yang dipilih, termasuk tanggal tanpa catatan sebelumnya.
- Tambah rincian maupun tambah satu pengeluaran menggunakan tanggal yang dipilih pada kalender.
- Total bulanan, jumlah item, laporan, dan fungsi hapus item tetap diperbarui.

## Identitas/build yang dipertahankan
- Package: `com.tokoku.app`
- versionCode: `139`
- versionName: `3.22.15-v139-expense-date-list`
- Java Temurin 17, Gradle 8.7, Android SDK 35
- Workflow menggunakan secrets keystore yang sama agar kompatibilitas update dipertahankan.

Upload `UsahoDen-v139-Pengeluaran-Tanggal-Vertikal-Source.zip` ke root repositori GitHub dan simpan workflow yang disediakan sebagai `.github/workflows/build.yml`. Jalankan melalui Actions → Build UsahoDen v139 Pengeluaran Tanggal Vertikal. Instal APK hanya setelah build sukses.
