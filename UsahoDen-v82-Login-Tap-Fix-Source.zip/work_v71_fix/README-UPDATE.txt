UsahoDen v70 - Halaman Tindakan terpisah dan ringkas.
Berbasis source v69. Menata halaman tindakan pasca transaksi dan mempertahankan handler tombol Print Struk, Kirim Gambar WA, Kirim Nota WA, Simpan Transaksi, dan Batal/Kembali ke Kasir.
Build dengan workflow versi 70 dan keystore permanen yang sama. Uji seluruh tombol di perangkat sebelum penggunaan produksi.


UsahoDen v75 WhatsApp button fix: share buttons resolve the current/latest sale if modal saleId is absent, and sharing no longer requires a saved customer phone number. Android share chooser lets the user choose WhatsApp/contact. Existing receipt rendering and transaction rules retained.

Build versionCode 75, versionName 3.22.15-kasir-v75-wa-buttons-fix.
