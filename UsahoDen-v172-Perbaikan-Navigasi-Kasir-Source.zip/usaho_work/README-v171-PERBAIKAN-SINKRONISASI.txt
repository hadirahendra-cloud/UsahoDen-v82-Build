UsahoDen v171 - Perbaikan Sinkronisasi Kasir

Perubahan utama:
- Tombol Ambil Data Produk & Pelanggan dari Admin membaca UID langsung dari kolom layar, membersihkan spasi, lalu menyimpan konfigurasi toko.
- Aktivasi sinkronisasi menentukan peran Admin/Kasir berdasarkan UID Firebase aktif dibanding UID Toko Admin, bukan username login lokal aplikasi.
- Transaksi disimpan ke antrean lokal untuk perangkat yang terdeteksi sebagai Kasir Firebase dan dikirim otomatis saat online.
- Konfigurasi UID dan antrean v170 dimigrasikan ke penyimpanan v171 agar data antrean lama tidak dibuang.
- Pembatasan menu kasir mengikuti peran perangkat Firebase setelah sinkronisasi diaktifkan.

Identitas aplikasi dipertahankan: com.tokoku.app. versionCode 171.
Build memakai Java Temurin 17, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0, Gradle 8.7 dan keystore lama dari GitHub Secrets.
