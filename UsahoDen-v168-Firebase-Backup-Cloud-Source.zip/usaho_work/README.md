# UsahoDen v168 — Firebase Backup Cloud

Basis source: UsahoDen v167 (Versi Tentang Aplikasi Otomatis).

## Perubahan v168
- Menambahkan Firebase Authentication email/password.
- Menambahkan Backup Cloud melalui Firebase Storage pada lokasi privat per UID pengguna: `backups/{uid}/usahoden-backup.json`.
- Menambahkan upload backup dan pemulihan backup dari menu Pengaturan.
- Data lokal `localStorage` tetap menjadi data kerja utama; tidak ada sinkronisasi otomatis. Upload hanya menyalin data lokal ke cloud. Pemulihan cloud mengganti data lokal setelah konfirmasi pengguna.
- Mempertahankan package `com.tokoku.app`, menaikkan versionCode ke 168 agar dapat dipasang sebagai pembaruan, dan mempertahankan fitur lain dari v167.

## Setup Firebase Console (wajib sebelum uji cloud)
1. Buka project Firebase `usahoden-rangmudojr`.
2. Authentication → Sign-in method → aktifkan **Email/Password**.
3. Storage → Get started / pastikan bucket Cloud Storage sudah dibuat.
4. Pada Storage Rules, terapkan isi file `storage.rules` di repositori ini lalu Publish. Aturan tersebut membatasi setiap akun hanya dapat membaca/menulis file backup pada UID miliknya sendiri.
5. Pastikan aplikasi Android terdaftar dengan package `com.tokoku.app` dan `app/google-services.json` adalah file dari project tersebut.

## Cara menggunakan
1. Instal APK v168 sebagai update di atas UsahoDen sebelumnya (jangan uninstall).
2. Buka Pengaturan → Backup Cloud Firebase.
3. Buat akun atau login menggunakan email/password Firebase.
4. Tekan **Backup Data** lokal terlebih dahulu sebagai salinan tambahan.
5. Tekan **Upload Backup ke Cloud** untuk menyimpan salinan terbaru.
6. Untuk memulihkan, login dengan akun yang sama lalu tekan **Pulihkan dari Cloud**. Pemulihan mengganti data lokal setelah konfirmasi.

## Build
Workflow GitHub Actions disiapkan dengan Java Temurin 17, Gradle 8.7, Android SDK `platform-tools`, `platforms;android-35`, `build-tools;35.0.0`, dan signing keystore lama melalui GitHub Secrets.

Secrets yang diperlukan: `TOKOKU_KEYSTORE_BASE64`, `TOKOKU_KEYSTORE_PASSWORD`, `TOKOKU_KEY_ALIAS`, dan opsional `TOKOKU_KEY_PASSWORD`.
