UsahoDen v163 - Notifikasi Global Fix

Dasar: source UsahoDen v162 yang diunggah pengguna.
Perubahan: posisi notifikasi global dihitung dari batas bawah header fixed sehingga notifikasi tidak tertutup header pada seluruh halaman. Lebar notifikasi dibatasi agar teks tetap terbaca; durasi dan pemanggilan toast dipertahankan.
Package ID: com.tokoku.app. Pertahankan signing keystore lama.


UsahoDen v165 - Smart Print Bluetooth Fix
- Based on user-confirmed v164 source.
- Adds paired-printer validation and clearer Bluetooth/offline printer error messages.
- Preserves package com.tokoku.app, receipt formatting, logo and 58/80 mm settings.
- versionCode 165; versionName 3.22.25-v165-smart-print-bluetooth-fix.


UsahoDen v166: kolom 'Nominal cicilan berikutnya' tidak lagi memiliki nilai bawaan 100000; kolom tampil kosong dan pengguna mengisi sendiri.
