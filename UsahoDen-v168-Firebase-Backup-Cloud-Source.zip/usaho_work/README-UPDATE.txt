UsahoDen v168 — Firebase Backup Cloud
Basis: UsahoDen v167.

Perubahan: integrasi Firebase Authentication email/password dan Firebase Storage untuk backup manual cloud per akun. Database lokal tetap dipertahankan sebagai data utama. Upload tidak menghapus data lokal. Restore cloud mengganti data lokal hanya setelah konfirmasi.

Wajib konfigurasi Firebase Console: aktifkan Authentication Email/Password, siapkan Storage bucket, dan terapkan storage.rules. Lihat README.md.

Package com.tokoku.app dipertahankan. versionCode 168, versionName 3.22.28-v168-firebase-backup-cloud. Build menggunakan Temurin 17, Gradle 8.7, Android SDK 35 dan signing keystore lama.
