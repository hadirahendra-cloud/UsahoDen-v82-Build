UsahoDen v100 — Header gonjong compact, logo sejajar dengan nama toko, deskripsi di bawah, tombol Keluar di tengah, label Admin dihapus. Perubahan hanya tampilan header.
