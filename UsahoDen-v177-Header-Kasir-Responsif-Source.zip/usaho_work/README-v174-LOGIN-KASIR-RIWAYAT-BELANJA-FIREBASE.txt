UsahoDen v174 - Login Kasir, Riwayat Transaksi, Belanja/Hari, dan Halaman Akun Firebase

Perubahan dari baseline resmi v173:
- Perangkat yang sudah tersimpan sebagai deviceRole=cashier pada konfigurasi sinkronisasi akan menampilkan username kasir pada layar login, bukan admin. Pada perangkat kasir, login lokal hanya menerima akun kasir; akun Admin tidak dapat digunakan untuk membuka perangkat kasir.
- Halaman Akun Firebase dipisahkan dari halaman Kasir dan disediakan sebagai tab khusus perangkat kasir.
- Tab Riwayat Transaksi dan Belanja/Hari diaktifkan pada perangkat kasir.
- Riwayat transaksi pada perangkat kasir bersifat lihat saja; tombol dan fungsi hapus transaksi diblokir.
- Hak akses perangkat kasir tetap dibatasi ke Kasir, Riwayat Transaksi, Belanja/Hari, dan Akun Firebase.
- Sinkronisasi Firebase, antrean transaksi offline, logika stok, dan data lokal v173 dipertahankan.

Identitas: applicationId com.tokoku.app. Keystore/signing tetap menggunakan secrets lama.
Build: Java Temurin 17, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0, Gradle 8.7.
