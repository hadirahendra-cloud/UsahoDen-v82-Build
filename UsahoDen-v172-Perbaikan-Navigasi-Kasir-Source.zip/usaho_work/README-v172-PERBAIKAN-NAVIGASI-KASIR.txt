UsahoDen v172 - Perbaikan Navigasi dan Pemisahan Halaman Kasir

Perbaikan terarah berdasarkan perbedaan tampilan HP Admin dan HP Kasir pada v171:
- Memperbaiki bug pembatasan akses Kasir yang sebelumnya memberi style display:block pada beberapa section sekaligus. Kini perpindahan halaman kembali memakai class .section.active dan fungsi go() sehingga Kasir, Pilih Produk, dan form tambah produk tampil terpisah.
- Navigasi bawah tetap terlihat pada perangkat Kasir. Tombol halaman Admin tetap dibatasi oleh pemeriksaan peran di fungsi go(); perangkat Kasir tidak memperoleh akses pengelolaan toko.
- Tombol Menu tidak membuka menu pengelolaan pada perangkat Kasir.
- Pemeriksaan peran Firebase pada fungsi navigasi menggunakan konfigurasi deviceRole.
- Fitur transaksi, antrean offline, sinkronisasi Firebase, data lokal, struk, dan backup v171 dipertahankan tanpa perubahan logika bisnis.

Identitas aplikasi: com.tokoku.app. versionCode 172.
SDK build: Java Temurin 17, Android SDK platform-tools/platforms;android-35/build-tools;35.0.0, Gradle 8.7.
