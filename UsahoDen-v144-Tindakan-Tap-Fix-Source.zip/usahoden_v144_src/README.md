# UsahoDen v144 — Tindakan Tap Fix

Basis: v143 Piutang Khusus Beranda. Perubahan terbatas: mencegah seleksi teks long-press pada tombol di Android WebView agar tombol Tindakan lebih mudah ditekan. Package com.tokoku.app; versionCode 144; pertahankan keystore lama, Java Temurin 17, Gradle 8.7, Android SDK 35.
