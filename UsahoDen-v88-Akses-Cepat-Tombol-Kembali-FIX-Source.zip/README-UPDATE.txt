UsahoDen v84 - Urutan Tanggal Riwayat FIX

Berdasarkan source v83 yang tampilan Riwayat Scroll-nya sudah berhasil.
Perubahan khusus v84:
- Urutan transaksi pelanggan di Riwayat Transaksi menggunakan tanggal/waktu transaksi yang diparse sebagai tanggal sebenarnya.
- Transaksi terbaru ditampilkan terlebih dahulu; transaksi lama di bawahnya.
- Tidak mengubah alur login, data, nota, WhatsApp, atau fitur transaksi lainnya.
- applicationId tetap com.tokoku.app; versionCode dinaikkan ke 84.

Build workflow: UsahoDen-v84-build.yml
Pastikan ZIP ini dibangun dengan keystore lama agar dapat update tanpa uninstall.
