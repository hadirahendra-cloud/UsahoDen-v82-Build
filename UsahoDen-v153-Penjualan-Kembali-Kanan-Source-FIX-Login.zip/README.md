# UsahoDen v143 — Piutang Khusus Beranda

Baseline: UsahoDen v142.

Perubahan terbatas: kartu Produk di Beranda diganti menjadi Piutang Khusus. Nilai otomatis menjumlahkan nilai total nota (`total`) dari transaksi baru berjenis `installment` pada tanggal lokal hari ini. Transaksi tunai, transaksi gabungan yang membayar piutang lama, dan pembayaran cicilan lama tidak ikut dihitung. Nilai dihitung ulang dari data transaksi yang tersimpan setiap kali dashboard dirender.

Package tetap `com.tokoku.app`; versionCode 143; Java Temurin 17; Gradle 8.7; Android SDK 35/build-tools 35.0.0; gunakan signing keystore lama agar update kompatibel.
