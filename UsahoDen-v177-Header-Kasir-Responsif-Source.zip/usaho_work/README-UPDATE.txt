UsahoDen v169 — Firebase Realtime Database Backup.
Basis: v168. Storage upload/download replaced with Realtime Database. See README.md and database.rules.


UsahoDen v176 - Header Kasir Fix
Perubahan hanya merapikan header pada perangkat Kasir agar proporsional dan konsisten dengan header Admin. Fitur lain dipertahankan dari v175.


UsahoDen v177 - Responsive Header Kasir
Header perangkat Kasir memakai layout responsif berbasis lebar layar. Logo di kiri, teks di kanan, deskripsi membungkus sesuai ruang, tombol Keluar berada pada baris tersendiri di bawah konten. Hanya header perangkat Kasir yang diubah.
