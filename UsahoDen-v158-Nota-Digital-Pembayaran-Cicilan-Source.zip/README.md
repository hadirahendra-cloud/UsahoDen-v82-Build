UsahoDen v158 — Nota Digital Pembayaran Cicilan

Basis source: v156 Pengaturan Printer Manual.

Perubahan: dialog Bayar Cicilan menyediakan tombol “Simpan & Buat Nota Digital” dan “Simpan Pembayaran Saja”. Pembayaran dicatat satu kali di db.payments, piutang pelanggan dikurangi sekali, dan tidak dibuat transaksi penjualan baru. Nota digital memuat pelanggan, nomor/tanggal nota, utang sebelum pembayaran, jumlah dibayar, dan sisa utang serta dapat dibagikan melalui AndroidShare.

Build menggunakan Java Temurin 17, Gradle 8.7, Android SDK platform-tools, platforms;android-35, build-tools;35.0.0 dan keystore lama.
