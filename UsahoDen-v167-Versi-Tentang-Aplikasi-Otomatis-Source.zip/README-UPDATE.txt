UsahoDen v167 - Versi Tentang Aplikasi Otomatis

Perubahan:
- Halaman Tentang Aplikasi tidak lagi menampilkan teks versi tetap v158.
- MainActivity membaca versionName dari PackageManager Android saat halaman dimuat.
- Label menampilkan pola vNNN yang diambil dari versionName APK terpasang.
- VersionCode 167.
- VersionName 3.22.27-v167-versi-tentang-otomatis.

Patokan:
- package com.tokoku.app
- Java Temurin 17
- Gradle 8.7 (workflow)
- Android SDK platform-tools, platforms;android-35, build-tools;35.0.0
- Signing menggunakan keystore lama melalui GitHub Secrets.

Perubahan dibatasi pada pembacaan versi aplikasi. Fitur v166, termasuk kolom nominal cicilan kosong, dipertahankan.
