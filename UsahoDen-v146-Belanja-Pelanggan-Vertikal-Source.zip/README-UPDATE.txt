UsahoDen v143 Piutang Khusus Beranda

Dasar: source v142 yang dikunci sukses.
Mengganti kartu Produk pada Beranda dengan Piutang Khusus. Kalkulasi hanya menjumlahkan total nota transaksi baru dengan type installment pada tanggal lokal hari ini. Pembayaran cicilan piutang lama dan transaksi type combined/cash tidak dihitung.

Build melalui workflow GitHub Actions dan secrets signing lama. Package com.tokoku.app. Jangan membuat keystore baru.
