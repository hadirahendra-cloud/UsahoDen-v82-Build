# TokoKu v3.22.15 - Pengeluaran Harian

Versi ini memakai source TokoKu v3.22.9 Printer Bluetooth sebagai dasar dan menambahkan/menjaga fitur Pengeluaran Harian.

## Fitur Pengeluaran Harian
- Tab pengeluaran berdasarkan tanggal.
- Pilih bulan.
- Total pengeluaran bulanan.
- Jumlah item pengeluaran.
- Rincian item per hari.
- Tambah beberapa item dalam satu tanggal.
- Kategori, jumlah, satuan, harga satuan, dan catatan.
- Hapus item pengeluaran.
- Laporan bulanan menghitung Penjualan - Pengeluaran.
- Laporan Laba & Rugi menghitung laba bersih setelah pengeluaran.

## Build APK
GitHub Actions: `.github/workflows/build-v3.22.15-pengeluaran-harian.yml`

Workflow sengaja membuat **DEBUG APK tanpa proses keystore/signing manual**, supaya tidak terkena kegagalan `Sign APK` yang terjadi pada workflow sebelumnya.

Hasil artifact:
`TokoKu-v3.22.15-Pengeluaran-Harian.apk`

Catatan: APK debug memiliki tanda tangan debug. Jika Android menolak instalasi karena ada versi TokoKu lama dengan signature berbeda, uninstall versi lama terlebih dahulu atau gunakan data backup/restore yang kompatibel.


Nota digital v51: tinggi kanvas menyesuaikan jumlah produk dan panel pembayaran/piutang agar footer Jazakumullah Khairon, BSI, DANA, dan WhatsApp tetap masuk. Logo RangMudo Jr digunakan sebagai fallback bila logo toko belum diatur.


Versi v64: perapian header fixed yang lebih pendek, panel dan formulir lebih ringkas. Build workflow ada di `.github/workflows/build.yml`. Build bertanda tangan membutuhkan GitHub Actions secrets untuk keystore permanen.


Update v68: source berbasis v66 dengan CSS halaman Pilih Produk yang dimasukkan pada blok style yang benar. Versi aplikasi 68.


## Perubahan v101
- Tinggi header dipangkas menjadi sekitar 50% dari v100.
- Area konten dinaikkan mengikuti tinggi header baru.
- Hanya CSS tata letak header yang diubah; struktur fitur dan data aplikasi tidak disentuh.
- versionCode dinaikkan ke 101 agar dapat dipasang sebagai pembaruan bila APK ditandatangani dengan keystore yang sama.
