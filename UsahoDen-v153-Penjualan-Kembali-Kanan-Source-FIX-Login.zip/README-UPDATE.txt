UsahoDen v148 - Rincian Belanja Pelanggan Header Fix

Dasar: source v147 yang dikunci sukses.
Perubahan tunggal: saat halaman rincian belanja pelanggan dibuka, sembunyikan tombol Kembali global paling atas dan rapatkan rincian ke bawah header. Tombol Kembali di samping judul rincian tetap tersedia.
Pertahankan package com.tokoku.app dan signing keystore lama.
